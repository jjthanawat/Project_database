﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace coffee_shop_project
{
    public partial class Total : Form
    {
        List<string> Array_name_products = new List<string>(); //เก็บ รายชื่อ สินค้าเป็นลิสต์
        List<int> Array_total_glass = new List<int>(); //เก็บ ไอดี สินค้าเป็นลิสต์
        List<float> Array_total_price = new List<float>(); //เก็บ ราคา สินค้าเป็นลิสต์

        public string staff_Level = "";
        public string staff_ID = "";
        public string staff_Name = "";


        public Total()
        {
            InitializeComponent();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Hide();
            Manu00 M1 = new Manu00();
            M1.label1.Text = staff_Level;
            M1.label3.Text = staff_ID;
            M1.label4.Text = staff_Name;
            M1.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide(); //ซ้อนหน้า Regis_Customer
            Form1 F1 = new Form1();
            F1.Show();  //เปิดหน้า Form1(หน้าคิดเงิน)
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            add_proucts A1 = new add_proucts();
            A1.Show();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            this.Hide();
            Regis_Customer M1 = new Regis_Customer();
            M1.Show();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            this.Hide();
            Staff_login S1 = new Staff_login();
            S1.Show();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            DialogResult iExit;
            iExit = MessageBox.Show("ต้องการปิดโปรแกรมใช่หรือไม่ ?", "ปิดโปรแกรม", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (iExit == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Array_name_products.Clear();
            Array_total_glass.Clear();
            Array_total_price.Clear();
            chart1.Series.Clear();
            chart1.Titles.Clear();



            //this.chart1.Series.Clear(); //
            //DateTime time = DateTime.Now;              // ใช้เวลาปัจจุบุน
            //string format = "yyyy-MM-dd HH:mm:ss";    //รูปแบบวันที่เลือกเป็น ปี เดือน วันที่ ชม. น. ว.
            string format = "yyyy-MM-dd HH:mm:ss";

            //อันเก่า//string sql = "SELECT products.ProductName,products.ProductID,sales.SaleDateTime,sale_details.ProductID,SUM(sale_details.Price) FROM products INNER JOIN sales INNER JOIN sale_details WHERE sales.SaleDateTime BETWEEN '" + dateTimePicker1.Value.ToString(format) + "' and '" + dateTimePicker2.Value.ToString(format) + "' and products.ProductID=sale_details.ProductID GROUP BY products.ProductID";
            string sql = "SELECT products.ProductName,products.ProductID,sales.SaleDateTime,SUM(sale_details.Price),SUM(sale_details.Amount/2) FROM products INNER JOIN sales INNER JOIN sale_details WHERE sales.SaleDateTime BETWEEN '" + dateTimePicker1.Value.ToString(format) + "' and '" + dateTimePicker2.Value.ToString(format) + "' and products.ProductID=sale_details.ProductID GROUP BY products.ProductID";
            MySqlConnection con = new MySqlConnection("host = localhost;user=root;password=123456789;database=py_database");
            MySqlCommand cmd = new MySqlCommand(sql, con);
            con.Open();
            MySqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                Array_name_products.Add(reader.GetString("ProductName"));
                Array_total_glass.Add(reader.GetInt32("SUM(sale_details.Amount/2)"));
                Array_total_price.Add(reader.GetFloat("SUM(sale_details.Price)"));
            }
            con.Close();

            //------------------------------------------------------------------------------------------
            int Percent_total_price = 0;    //เก็บราคารวมทั้งหมดใน list เพื่อจะคำนวนเป็น %
            foreach (int i in Array_total_price)
            {
                Percent_total_price = Percent_total_price + i;
            }

            int total_grass = 0;
            foreach (int j in Array_total_glass)
            {
                total_grass = total_grass + j;
            }
            //------------------------------------------------------------------------------------------

            //select * from sales where SaleDateTime between '2020-04-24 12:48:41'and'2020-04-24 12:48:41';

            //AddXY value in chart1 in series named as Salary
            chart1.Series.Add("Products").ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Bar;
            chart1.Series.Add("Percent of price (%)").ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Bar;


            for (int i = 0; i < Array_name_products.Count; i++)
            {
                this.chart1.Series["Products"].Points.AddXY("" + Array_name_products[i] + " " + Array_total_glass[i] + " แก้ว\n" + Array_total_price[i] + " บาท\n" + (Array_total_price[i] * 100) / Percent_total_price + " %", "" + Array_total_price[i] + "");
                this.chart1.Series["Percent of price (%)"].Points.AddXY("" + Array_name_products[i] + " " + Array_total_glass[i] + " แก้ว\n" + Array_total_price[i] + " บาท\n" + (Array_total_price[i] * 100) / Percent_total_price + " %", "" + Array_total_price[i] + "");

            }

            chart1.Titles.Add("กราฟแสดงสัดส่วนการขายของสินค้าทั้งหมด " + total_grass + " แก้ว รวมเป็นเงิน " + Percent_total_price + " บาท");


            if (Percent_total_price == 0)
            {
                label3.Text = "ไม่มีข้อมูลที่จะแสดง กรุณาเลือกวันที่ไหม่";
            }
            else
            {
                label3.Text = "";
            }

            /*this.chart1.Series["Series"].Points.AddXY("Ajay", "10");
            this.chart1.Series["Series"].Points.AddXY("Ramesh", "20");
            this.chart1.Series["Series"].Points.AddXY("Ankit", "30");
            this.chart1.Series["Series"].Points.AddXY("Gurmeet", "40");
            this.chart1.Series["Series"].Points.AddXY("Suresh", "50");
            //chart title  
            ;*/
        }

        private void Total_Load(object sender, EventArgs e)
        {
        }

        private void button2_Click(object sender, EventArgs e)
        {
        }
    }
}
