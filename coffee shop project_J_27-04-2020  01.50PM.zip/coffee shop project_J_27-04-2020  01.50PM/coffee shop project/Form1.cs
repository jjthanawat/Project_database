﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace coffee_shop_project
{
    public partial class Form1 : Form
    {
        public int totalprice; //เก็บราคารวม โดยบวกไปเรื่อยๆ
        public int prices;  //เก็บราคาเฉพาะต่อชิ้น
        public int before_point; //เก็บแต้มต่อคน จากฐานข้อมูล
        //public int Now_point; //เก็บแต้มปัจจุบัน

        //List<string> Array_Sales_ID = new List<string>();//เก็บ ไอดี สินค้าเป็นอาเรย์
        List<string> Array_Product_ID = new List<string>();
        List<string> Array_price = new List<string>(); //เก็บ ราคา สินค้าเป็นอาเรย์
        List<string> Array_name_products = new List<string>(); //เก็บ รายชื่อ สินค้าเป็นอาเรย์



        public Form1()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            add_proucts A1 = new add_proucts();
            A1.label20.Text = label20.Text;
            A1.label23.Text = label23.Text;
            A1.Show();
            A1.Show();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            comboBox1.Items.Clear(); //ลบค่าใน comboBox1 ทั้งหมด
            string sql = "select * from products";
            MySqlConnection con = new MySqlConnection("host = localhost;user=root;password=123456789;database=py_database");

            MySqlCommand cmd = new MySqlCommand(sql, con);
            con.Open();
            MySqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                string product = reader.GetString("ProductName");
                comboBox1.Items.Add(product); //เพิ่มค่าใน comboBox1 ทั้งหมด
            }
            //cmd.ExecuteNonQuery();
            con.Close();


        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int x1 = 1 + listBox1.Items.Count; //นับจำนวนรายการทั้งหมด
            label21.Text = "ทั้งหมด   " + x1.ToString() + "   รายการ";


            int cal_price = 0;
            string N_product = comboBox1.Text; //เครื่องดื่ม
            string T_product = comboBox2.Text; //ชนิดเครื่องดื่ม
            string O_product = comboBox3.Text; //เพิ่มเติม

            //-----------------------------------------------------------------------------------------//

            string sql = "SELECT ProductID,Price FROM products WHERE ProductName ='" + N_product + "'";
            MySqlConnection con = new MySqlConnection("host = localhost;user=root;password=123456789;database=py_database");
            MySqlCommand cmd = new MySqlCommand(sql, con);
            con.Open();
            MySqlDataReader reader = cmd.ExecuteReader();
            if (reader.Read())
            {
                string productid = reader.GetString("ProductID");
                cal_price = reader.GetInt32("Price"); //เก็บราคา
                prices = reader.GetInt32("Price"); //เก็บราคาเฉพาะชิ้น
                totalprice = totalprice + cal_price; //เก็บราคารวม โยกการบวกราคาไปเรื่อยๆ

                Array_Product_ID.Add(productid);
                Array_name_products.Add(N_product);//+++++++++++++++++++++++++++++++++array product_name
                Array_price.Add(cal_price.ToString());//+++++++++++++++++++++++++array price
            }
            con.Close();


            //cal_price = cal_price + totalprice;
            string x = totalprice.ToString(); //แปลงค่าเพื่อแสดงใน textBox1
            textBox1.Text = x; //แสดงราคารวม
            //-----------------------------------------------------------
            if (N_product == "เลือกเครื่องดื่ม") //เช็คเงื่อนไข เลือกเครื่องดื่มหรือยัง
            {
                MessageBox.Show("เครื่องดื่มยังไม่ถูกเลือก");
            }
            else
            {
                if (T_product == "ชนิด") //เช็คเงื่อนไข เลือกชนิดเครื่องดื่มหรือยัง
                {
                    MessageBox.Show("ชนิดเครื่องดื่มยังไม่ถูกเลือก");
                }
                else
                {
                    //listBox1.Items.Add("" + N_product + " " + T_product + "");
                    listBox1.Items.Add(N_product); //แสดชื่อ
                    listBox2.Items.Add(T_product);  //แสดงชนิด
                    listBox3.Items.Add(O_product);  //เพิ่มเติม
                    listBox4.Items.Add(prices); //แสดงราคา
                }
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            label21.Text = "ทั้งหมด 0 รายการ";
            Array_Product_ID.Clear();
            Array_name_products.Clear();
            Array_price.Clear();
            listBox1.Items.Clear();
            listBox2.Items.Clear();
            listBox3.Items.Clear();
            listBox4.Items.Clear();

            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();

            totalprice = 0;
            textBox1.Text = totalprice.ToString();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            int total_product = 1 + listBox1.Items.Count; //เก็บจำนวนแก้ว
            int total_product2 = listBox1.Items.Count;
            //string DateText = DateTime.Now.ToLongDateString(); //เก็บวันที่
            string saleid = "";//เก็บ ไอดีของการขาย เมื่อขายเสร็จสิ้น
            DateTime time = DateTime.Now;              // ใช้เวลาปัจจุบุน
            string format = "yyyy-MM-dd HH:mm:ss";    //รูปแบบวันที่เลือกเป็น ปี เดือน วันที่ ชม. น. ว.
            //'" + time.ToString(format) + "'


            if (textBox4.Text != "" && textBox1.Text != "" && textBox2.Text != "") //เช็คเงื่อนไข ถ้าหาก textbox1,2,4 ว่าง แสดงว่ายังไม่ได้คิดเงิน
            {
                //---------------------------------------ดึงข้อมูลแต้มจากฐานข้อมูล-----------------------------
                int ID = 0;
                int CustomerID = int.Parse(textBox4.Text);
                string sql = "SELECT * FROM customers where CustomerID ='" + CustomerID + "'";
                MySqlConnection con = new MySqlConnection("host = localhost;user=root;password=123456789;database=py_database");
                MySqlCommand cmd = new MySqlCommand(sql, con);
                con.Open();
                MySqlDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    before_point = reader.GetInt32("customers_points");
                    ID = reader.GetInt32("CustomerID");
                    //before_point = before_point + readpoint;
                }
                con.Close();
                //-------------------------------------------------------------------------------------



                //-----------------UPDATE `customers` SET `customers_points` = '1' WHERE `customers`.`CustomerID` = 1;
                if (textBox4.Text != "") //เช็คเงื่อนไข ถ้า textBox4 ว่าง แสดงว่ายังไม่ใส่ ID ของลูกค้า
                {
                    if (textBox1.Text == "" || textBox1.Text == "0") //เช็คเงื่อนไข textBox1 ว่างหรือเท่ากับ 0 หรือไม่
                    {
                        //ไม่ต้องทำอะไร
                    }
                    else
                    {
                        if (textBox2.Text != "") //เช็คเงื่อนไขถ้า textBox2 ไม่ว่าง
                        {
                            if (ID == 0)
                            {
                                MessageBox.Show("ID : " + textBox4.Text + " ในฐานข้อมูล กรุณาสมัครสมาชิก");
                            }
                            else
                            {


                                //---------------------------สะสมแต้ม-----------------------------------//

                                int now_points = (totalprice / 25) + before_point; //เอาแต้มก่อนหน้า บวกกับแต้มที่ได้ในครั้งนี้ อัพเดทแต้มที่ฐานข้อมูล
                                sql = "UPDATE customers SET customers_points = '" + now_points + "' WHERE customers.CustomerID = '" + CustomerID + "'";
                                cmd = new MySqlCommand(sql, con);
                                con.Open();
                                reader = cmd.ExecuteReader();
                                con.Close();
                                //---------------------------สะสมแต้ม-----------------------------------//




                                //----------------------------------เก็บข้อมูลการขาย===sales=== --------------------------------------------------------------------
                                sql = "INSERT INTO `sales` (`SaleID`, `SaleDateTime`, `CustomerID`, `StaffID`, `GrandTotal`) " +
                                    "VALUES (NULL, '" + time.ToString(format) + "', '" + textBox4.Text + "', '" + label20.Text + "', '" + total_product2 + "')";
                                cmd = new MySqlCommand(sql, con);
                                con.Open();
                                reader = cmd.ExecuteReader();
                                con.Close();
                                //------------------------------------------------------------------------------------------------------------------
                                sql = "select SaleID from sales where CustomerID='" + textBox4.Text + "' and StaffID = '" + label20.Text + "' and GrandTotal='" + total_product2 + "';";
                                cmd = new MySqlCommand(sql, con);
                                con.Open();
                                reader = cmd.ExecuteReader();
                                if (reader.Read())
                                {
                                    saleid = reader.GetString("SaleID");
                                    /////////////////////////////////////////////////////////////////////////////////
                                }
                                con.Close();

                                //*****************************************************************************************
                                //เพิ่มข้อมูลในหน้า sale_detail
                                //*****************************************************************************************
                                for (int i = 0; i < Array_name_products.Count; i++)
                                {

                                    sql = "INSERT INTO `sale_details` " +
                                        "(`SaleDetailID`, `SaleID`, `ProductID`, `Price`, `Quantity`, `Amount`)" +
                                        " VALUES (NULL, '" + saleid + "', '" + Array_Product_ID[i] + "', '" + Array_price[i] + "', '1', '1');";
                                    cmd = new MySqlCommand(sql, con);
                                    con.Open();
                                    reader = cmd.ExecuteReader();
                                    con.Close();
                                }




                                //**********************************************************************//
                                //**********************************************************************//
                                //------------------------------------------------------------------------------------------------------------------

                                int total = int.Parse(textBox2.Text) - totalprice; //ลบจำนวนเงินที่ได้จากลูกค้า กับ ราคาทั้งหมด
                                textBox3.Text = total.ToString(); //แปลงค่าเป็นข้อความ
                                MessageBox.Show("ชำระเงินเสร็จสิ้น");



                                if (int.Parse(textBox3.Text) < 0)   //เช็นเงื่อนไข ถ้าเงินทอนติดลบ
                                {
                                    int c = int.Parse(textBox3.Text) * (-1); //คูณจำนวนที่ติดลบเข้ากับ -1
                                    MessageBox.Show("จำนวนเงินไม่พอจ่ายอีก " + c + " บาท"); //แสดงเงินที่ต้องจ่ายเพิ่ม
                                }
                            }
                        }
                        else //ถ้าช่องรับเงินจากลูกค้าว่าง
                        {
                            MessageBox.Show("กรุณาใส่จำนวนเงินที่ได้รับจากลูกค้า");
                        }

                    }
                }
                else
                {
                    MessageBox.Show("กรุณาใส่ ID ของลูกค้า");
                }
            }
            else
            {
                MessageBox.Show("กรุณาใส่ ID ลูกค้า\nและทำการชำระเงินก่อน");
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (textBox4.Text != "" && textBox1.Text != "" && textBox2.Text != "" && textBox3.Text != "") //ถ้า textBox4 ไม่ว่าง
            {
                //int ttp = 0;
                int CustomerID = int.Parse(textBox4.Text);
                string sql = "SELECT * FROM customers where CustomerID ='" + CustomerID + "'";
                MySqlConnection con = new MySqlConnection("host = localhost;user=root;password=123456789;database=py_database");
                MySqlCommand cmd = new MySqlCommand(sql, con);
                con.Open();
                MySqlDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    int Npoint = totalprice / 25;
                    string cus_ID = reader.GetString("CustomerID"); //เก็บราคา)
                    string cus_name = reader.GetString("CustomerName"); //เก็บราคาเฉพาะชิ้น
                    string cus_tel = reader.GetString("CustomerTelNo");
                    //int cus_Bpoint = reader.GetInt32("customers_points") - Npoint;


                    label14.Text = "ไอดีลูกค้า :" + cus_ID + "";
                    label15.Text = "ชื่อลูกค้า :" + cus_name + "";
                    label19.Text = "เบอร์โทรลูกค้า :" + cus_tel + "";
                    label16.Text = "แต้มก่อนหน้านี้ :" + before_point.ToString() + "";
                    label17.Text = "แต้มที่ได้ในครั้งนี้ :" + Npoint + "";
                    int x = before_point + Npoint;  //เอาแต้มที่ได้ในครั้งนี้ บวกกับแต้มที่อ่านได้จากฐานข้อมูล
                    label18.Text = "รวมแต้มทั้งหมด " + x + "";

                }
                con.Close();
            }
            else //ถ้า textBox4 ว่าง
            {
                MessageBox.Show("กรุณาใส่ ID ของลูกค้า\nและทำการชำระเงินก่อน");
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            DialogResult iExit;
            iExit = MessageBox.Show("ต้องการปิดโปรแกรมใช่หรือไม่ ?", "ปิดโปรแกรม", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (iExit == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            this.Hide();
            Staff_login S1 = new Staff_login();
            S1.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Hide();
            Regis_Customer M1 = new Regis_Customer();
            M1.label20.Text = label20.Text;
            M1.label23.Text = label23.Text;
            M1.Show();
        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void button10_Click(object sender, EventArgs e)
        {
            this.Hide();
            Manu00 M1 = new Manu00();

            int staff_ID = int.Parse(label20.Text);
            string sql = "SELECT StaffLevel FROM staffs where StaffID ='" + staff_ID + "'";
            MySqlConnection con = new MySqlConnection("host = localhost;user=root;password=123456789;database=py_database");
            MySqlCommand cmd = new MySqlCommand(sql, con);
            con.Open();
            MySqlDataReader reader = cmd.ExecuteReader();
            if (reader.Read())
            {
                M1.label1.Text = reader.GetString("StaffLevel");
                M1.label3.Text = label20.Text;
                M1.label4.Text = label23.Text;
            }
            con.Close();
            M1.Show();
        }
    }
}
