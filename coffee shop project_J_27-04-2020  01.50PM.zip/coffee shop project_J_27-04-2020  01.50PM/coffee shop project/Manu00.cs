﻿using System;
using System.Windows.Forms;

namespace coffee_shop_project
{
    public partial class Manu00 : Form
    {
        public Manu00()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            DialogResult iExit;
            iExit = MessageBox.Show("ต้องการปิดโปรแกรมใช่หรือไม่ ?", "ปิดโปรแกรม", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (iExit == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Staff_login R1 = new Staff_login();
            R1.Show();

        }

        private void Manu00_Load(object sender, EventArgs e)
        {
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            add_proucts A1 = new add_proucts();
            A1.label20.Text = label3.Text;
            A1.label23.Text = label4.Text;
            A1.Show();
            A1.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 F1 = new Form1();
            F1.label20.Text = label3.Text;
            F1.label23.Text = label4.Text;
            F1.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Hide();
            Regis_Staff R1 = new Regis_Staff();
            R1.label20.Text = label3.Text;
            R1.label23.Text = label4.Text;
            R1.Show();
            R1.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.Hide();
            Regis_Customer R1 = new Regis_Customer();
            R1.label20.Text = label3.Text;
            R1.label23.Text = label4.Text;
            R1.Show();
            R1.Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            this.Hide();
            Total T1 = new Total();
            T1.staff_Level = label1.Text;
            T1.staff_ID = label3.Text;
            T1.staff_Name = label4.Text;
            T1.Show();
        }
    }
}
