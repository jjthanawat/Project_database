﻿using MySql.Data.MySqlClient;
using System;
using System.Windows.Forms;


namespace coffee_shop_project
{
    public partial class add_proucts : Form
    {
        public add_proucts()
        {
            InitializeComponent();
        }

        private void add_proucts_Load(object sender, EventArgs e)
        {
            listBox1.Items.Clear(); //ลบข้อมูลใน listbox1 ทั้งหมด
            string sql = "select * from products";
            MySqlConnection con = new MySqlConnection("host = localhost;user=root;password=123456789;database=py_database");

            MySqlCommand cmd = new MySqlCommand(sql, con);
            con.Open();
            MySqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                string productname = reader.GetString("ProductName");   //อ่านชื่อสินค้าจากฐานข้อมูล
                string productprice = reader.GetString("Price"); //อ่านราคาสินค้าจากฐานข้อมูล
                string productID = reader.GetString("ProductID");
                string productdetail = reader.GetString("ProductDetail");
                listBox1.Items.Add("ID : " + productID + ""); //เพิ่มสินค้าใน listbox1
                listBox1.Items.Add(productname);
                listBox1.Items.Add("ราคา : " + productprice + " บาท");
                listBox1.Items.Add("ราลละเอียด :"+productdetail+"");
                listBox1.Items.Add("");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string Nproduct = textBox1.Text; //เก็บค่ารายชื่อสินค้า
            string Pproduct = textBox2.Text; //เก็บค่าราคาสินค้า
            string Detail = textBox3.Text;  //เก็บรายละเอียดสินค้า
            string sql = "select * from products";


            if (Nproduct.Length != 0 && Pproduct.Length != 0 && Detail!="")
            {
                sql = "INSERT INTO products (ProductName, Price, ProductDetail) VALUES('" + Nproduct + "', '" + Pproduct + "', '" + Detail + "')";
                MySqlConnection con = new MySqlConnection("host = localhost;user=root;password=123456789;database=py_database");

                MySqlCommand cmd = new MySqlCommand(sql, con);
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("เพิ่มสินค้าเสร็จสิน กรุณากดปุ่ม 'อัพเดท'");
                textBox1.Clear();
                textBox2.Clear();
                textBox3.Clear();
            }
            else
            {
                MessageBox.Show("กรุณาใส่ชื่อ และราคาของสินค้าให้ครบทุกช่อง\nยกเว้น ช่อง'รายละเอียดสินค้า' หากไม่มีข้อมูล ให้ใส่เครื่องหมาย ' - '");
            }
            /*
            listBox1.Items.Add(Nproduct);
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            MessageBox.Show("เพิ่มสินค้าเสร็จสิน กรุณากดปุ่ม 'อัพเดท'");
            */
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 F1 = new Form1();
            F1.label20.Text = label20.Text;
            F1.label23.Text = label23.Text;
            F1.Show();
            F1.Show();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear(); //ลบข้อมูลใน listbox1 ทั้งหมด
            string sql = "select * from products";
            MySqlConnection con = new MySqlConnection("host = localhost;user=root;password=123456789;database=py_database");

            MySqlCommand cmd = new MySqlCommand(sql, con);
            con.Open();
            MySqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                string productname = reader.GetString("ProductName");   //อ่านชื่อสินค้าจากฐานข้อมูล
                string productprice = reader.GetString("Price"); //อ่านราคาสินค้าจากฐานข้อมูล
                string productID = reader.GetString("ProductID");
                string productdetail = reader.GetString("ProductDetail");
                listBox1.Items.Add("ID : " + productID + ""); //เพิ่มสินค้าใน listbox1
                listBox1.Items.Add(productname);
                listBox1.Items.Add("ราคา : " + productprice + " บาท");
                listBox1.Items.Add("ราลละเอียด :" + productdetail + "");
                listBox1.Items.Add("");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (listBox1.Text != "")
            {


                string sql = "DELETE FROM products WHERE ProductName = '" + listBox1.Text + "'";
                MySqlConnection con = new MySqlConnection("host = localhost;user=root;password=123456789;database=py_database");
                MySqlCommand cmd = new MySqlCommand(sql, con);
                con.Open();
                MySqlDataReader reader = cmd.ExecuteReader();
                //cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("ลบสินค้าในฐานข้อมูลแล้ว กรุณากด 'อัพเดท'");
            }
            else
            {
                MessageBox.Show("กรุณาเลือก 'ชื่อสินค้า' ที่ต้องการลบในหน้า 'สินค้าทั้งหมด'");
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            DialogResult iExit;
            iExit = MessageBox.Show("Do you want to exit ?", "program", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (iExit == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            this.Hide();
            Staff_login S1 = new Staff_login();
            S1.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Hide();
            Regis_Customer M1 = new Regis_Customer();
            M1.label20.Text = label20.Text;
            M1.label23.Text = label23.Text;
            M1.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            /*this.Hide();
            add_proucts A1 = new add_proucts();
            A1.Show();*/
        }

        private void button7_Click(object sender, EventArgs e)
        {
            //หน้าแรก
            this.Hide();
            Manu00 M1 = new Manu00();

            int staff_ID = int.Parse(label20.Text);
            string sql = "SELECT StaffLevel FROM staffs where StaffID ='" + staff_ID + "'";
            MySqlConnection con = new MySqlConnection("host = localhost;user=root;password=123456789;database=py_database");
            MySqlCommand cmd = new MySqlCommand(sql, con);
            con.Open();
            MySqlDataReader reader = cmd.ExecuteReader();
            if (reader.Read())
            {
                M1.label1.Text = reader.GetString("StaffLevel");
                M1.label3.Text = label20.Text;
                M1.label4.Text = label23.Text;
            }
            con.Close();
            M1.Show();
        }
    }
}
