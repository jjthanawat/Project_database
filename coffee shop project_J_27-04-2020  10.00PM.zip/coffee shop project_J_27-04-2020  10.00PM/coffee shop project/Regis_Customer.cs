﻿using MySql.Data.MySqlClient;
using System;
using System.Windows.Forms;

namespace coffee_shop_project
{
    public partial class Regis_Customer : Form
    {
        public Regis_Customer()
        {
            InitializeComponent();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide(); //ซ้อนหน้า Regis_Customer
            Form1 F1 = new Form1();
            F1.label20.Text = label20.Text;
            F1.label23.Text = label23.Text;
            F1.Show();  //เปิดหน้า Form1(หน้าคิดเงิน)
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string cus_name = textBox4.Text;    //ชื่อสมาชิก
            string cus_gender = comboBox1.Text;    //เลือก Item (เพศ)
            string cos_tel = textBox1.Text;    //เบอร์โทร
            if (cus_name != "" && cus_gender != "" && cos_tel != "")
            {


                string cus_gen = ""; //เก็บค่าว่างเปล่า
                if (cus_gender == "ชาย") //เช็กเงื่อนไข ถ้าเลือกคำว่า "ชาย"
                {
                    cus_gen = "M";  //ให้แทนด้วยตัว M
                }
                else if (cus_gender == "หญิง") //เช็กเงื่อนไข ถ้าเลือกคำว่า "หญิง"
                {
                    cus_gen = "F";  //ให้แทนด้วยตัว F
                }
                //--------------สมัครสมาชิก---------------
                string sql = "INSERT INTO `customers` " +
                          "(`CustomerID`, `CustomerName`, `Gender`, `CustomerType`, `CustomerTelNo`, `customers_points`) " +
                    "VALUES (NULL, '" + cus_name + "', '" + cus_gen + "', 'Member', '" + cos_tel + "', '0')";
                MySqlConnection con = new MySqlConnection("host = localhost;user=root;password=123456789;database=py_database");
                MySqlCommand cmd = new MySqlCommand(sql, con);
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
                //--------------สมัครสมาชิก---------------
            }
            else
            {
                MessageBox.Show("กรุณาใส่ข้อมูลในช่อง \n'ชื่อ - สกุล'  'เพศ' และ 'เบอร์โทร.'\nให้ครบทุกช่อง");
            }
            MessageBox.Show("สมัครสมาชอกเสร้จสิน กรุณากดปุ่ม 'อัพเดท'");
            textBox1.Clear();
            textBox4.Clear();
            




        }


        private void button2_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            string sql = "SELECT * FROM `customers`";
            MySqlConnection con = new MySqlConnection("host = localhost;user=root;password=123456789;database=py_database");
            MySqlCommand cmd = new MySqlCommand(sql, con);
            con.Open();
            MySqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                //CustomerID | CustomerName | Gender | CustomerType | CustomerTelNo | customers_points
                string cus_ID = reader.GetString("CustomerID");     //ไอดี
                string cus_Name = reader.GetString("CustomerName"); //ชื่อ
                string cus_Gender = reader.GetString("Gender");     //เพศ
                string cus_Tel = reader.GetString("CustomerTelNo"); //เบอร์โทร
                string cus_Points = reader.GetString("customers_points");   //แต้ม
                listBox1.Items.Add("ไอดี : " + cus_ID + "");
                listBox1.Items.Add(cus_Name);
                if (cus_Gender == "M")
                {
                    listBox1.Items.Add("เพศ ชาย  เบอร์โทร. " + cus_Tel + " แต้มทั้งหมด " + cus_Points + " แต้ม");
                    listBox1.Items.Add(" ");
                }
                else
                {
                    listBox1.Items.Add("เพศ หญิง  เบอร์โทร. " + cus_Tel + " แต้มทั้งหมด " + cus_Points + " แต้ม");
                    listBox1.Items.Add(" ");
                }
                



            }
            con.Close();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            ////////////////////ลบข้อมูลสมาชิก/////////////////////
            //DELETE FROM `customers` WHERE `customers`.`CustomerID` = 6;

            string customer_name = listBox1.Text;
            if (customer_name != "")
            {
                string sql = "DELETE FROM `customers` WHERE CustomerName = '" + customer_name + "'";
                MySqlConnection con = new MySqlConnection("host = localhost;user=root;password=123456789;database=py_database");
                MySqlCommand cmd = new MySqlCommand(sql, con);
                con.Open();
                MySqlDataReader reader = cmd.ExecuteReader();
                con.Close();
                MessageBox.Show("ลบรายชื่อรายชื่อเสร็จสิน");

            }
            else
            {
                MessageBox.Show("กรุณาเลือก 'รายชื่อ' ที่ต้องการลบในหน้า 'สมาชิกทั้งหมด'");
            }


        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            add_proucts A1 = new add_proucts();
            A1.label20.Text = label20.Text;
            A1.label23.Text = label23.Text;
            A1.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Hide();
            Manu00 M1 = new Manu00();

            int staff_ID = int.Parse(label20.Text);
            string sql = "SELECT StaffLevel FROM staffs where StaffID ='" + staff_ID + "'";
            MySqlConnection con = new MySqlConnection("host = localhost;user=root;password=123456789;database=py_database");
            MySqlCommand cmd = new MySqlCommand(sql, con);
            con.Open();
            MySqlDataReader reader = cmd.ExecuteReader();
            if (reader.Read())
            {
                M1.label1.Text = reader.GetString("StaffLevel");
                M1.label3.Text = label20.Text;
                M1.label4.Text = label23.Text;
            }
            con.Close();
            M1.Show();
        }

        private void Regis_Customer_Load(object sender, EventArgs e)
        {
            /*string cus_ID = "";     //ไอดี
            string cus_Name = ""; //ชื่อ
            string cus_Gender = "";     //เพศ
            string cus_Tel = ""; //เบอร์โทร
            string cus_Points = "";   //แต้ม
            */
            string sql = "SELECT * FROM `customers`";
            MySqlConnection con = new MySqlConnection("host = localhost;user=root;password=123456789;database=py_database");
            MySqlCommand cmd = new MySqlCommand(sql, con);
            con.Open();
            MySqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                //CustomerID | CustomerName | Gender | CustomerType | CustomerTelNo | customers_points
                string cus_ID = reader.GetString("CustomerID");     //ไอดี
                string cus_Name = reader.GetString("CustomerName"); //ชื่อ
                string cus_Gender = reader.GetString("Gender");     //เพศ
                string cus_Tel = reader.GetString("CustomerTelNo"); //เบอร์โทร
                string cus_Points = reader.GetString("customers_points");   //แต้ม
                listBox1.Items.Add("ไอดี : " + cus_ID + "");
                listBox1.Items.Add(cus_Name);
                if (cus_Gender == "M")
                {
                    listBox1.Items.Add("เพศ ชาย  เบอร์โทร. " + cus_Tel + " แต้มทั้งหมด " + cus_Points + " แต้ม");
                    listBox1.Items.Add(" ");
                }
                else
                {
                    listBox1.Items.Add("เพศ หญิง  เบอร์โทร. " + cus_Tel + " แต้มทั้งหมด " + cus_Points + " แต้ม");
                    listBox1.Items.Add(" ");
                }
                



            }
            con.Close();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button8_Click(object sender, EventArgs e)
        {

        }

        private void button10_Click(object sender, EventArgs e)
        {
            this.Hide();
            Staff_login S1 = new Staff_login();
            S1.Show();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            DialogResult iExit;
            iExit = MessageBox.Show("ต้องการปิดโปรแกรมใช่หรือไม่ ?", "ปิดโปรแกรม", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (iExit == DialogResult.Yes)
            {
                Application.Exit();
            }
        }
    }
}
