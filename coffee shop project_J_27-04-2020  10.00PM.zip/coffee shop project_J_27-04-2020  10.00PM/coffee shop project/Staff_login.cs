﻿using MySql.Data.MySqlClient;
using System;
using System.Windows.Forms;

namespace coffee_shop_project
{

    public partial class Staff_login : Form
    {

        public Staff_login()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            if (textBox2.Text != "" && textBox1.Text != "")
            {
                string staff_level; //เก็บ level ของ staff ที่อ่านได้จากฐานข้อมูล
                string staff_name;  //เก็บ name ของ staff ที่อ่านได้จากฐานข้อมูล


                string sql = "select * from staffs where StaffID = '" + textBox2.Text + "'and StaffPassword = '" + textBox1.Text + "'";
                MySqlConnection con = new MySqlConnection("host = localhost;user=root;password=123456789;database=py_database");
                MySqlCommand cmd = new MySqlCommand(sql, con);
                con.Open();
                MySqlDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    staff_level = reader.GetString("StaffLevel"); //อ่านระดับ
                    staff_name = reader.GetString("StaffName");//อ่านชื่อ

                    this.Hide();
                    Manu00 M1 = new Manu00();
                    M1.Show();
                    M1.label1.Text = staff_level;   //แสดงระดับในหน้า Manu00
                    M1.label4.Text = staff_name;    //แสดงชื่อในหน้า Manu00
                    M1.label3.Text = textBox2.Text;

                }
                else
                {
                    MessageBox.Show("ชื่อผู้ใช้ หรือรหัสผ่านไ ไม่ถูกต้อง");
                }
            }
            else
            {
                MessageBox.Show("กรุณาใส่ ชื่อผู้ใช้ และรหัสผ่าน");

            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            DialogResult iExit;
            iExit = MessageBox.Show("ต้องการปิดโปรแกรมใช่หรือไม่ ?", "ปิดโปรแกรม", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (iExit == DialogResult.Yes)
            {
                Application.Exit();
            }
        }
    }
}
